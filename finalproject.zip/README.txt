Gurkirat Singh Dhatt-Programmer Author

The purpose of this file is to submit the 2401 final project and has all the files that were completed to run the requirments needed,
It runs a simulation that is multi-threaded and executes 3 scenarios where the heroes and pirates fight and a pecentage summary is shown at the end to show the results of the fight scenarios.

List of Files

Source Files:
deque.c
fight.c
main.c
run.c
scenario.c

Header Files:
defs.h

No data files

To compile and launch the make file in this zip file 
Complaition command Make
Launch is ./main
for valgrind it is , valgrind ./main

Thanks for teaching this semester, have a happy holidays!


